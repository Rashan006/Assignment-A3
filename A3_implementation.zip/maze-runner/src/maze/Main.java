package maze;

import maze.util.Console;

public class Main {
    public static void main(String[] args) {
        new Console().start();
    }
}